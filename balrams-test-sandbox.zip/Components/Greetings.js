import React, { Component } from "react";
// import React from 'react';
// import React, { Component } from "react";

//class component
class Greetings extends Component {
  render() {
    return <h1> Greetings for the day!</h1>;
  }
}
export default Greetings;
