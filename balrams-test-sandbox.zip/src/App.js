import React from "react";
import "./styles.css";
import Greet from "/Components/Greet";
import Greetings from "/Components/Greetings";
import FunctionClick from "/Components/FunctionClick";

export default function App() {
  return (
    <div className="App">
      {/* <h1>Hello React</h1>
      <h2> balram</h2> */}

      {/* <Greet> </Greet>
      <Greetings /> */}
      <FunctionClick />
    </div>
  );
}
